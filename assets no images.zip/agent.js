/* agent.js — Agent One on the storefront, via the MindBehind Web Messenger.
   ---------------------------------------------------------------------------

   WHAT THIS IS

   Agent One is configured in InOne, but it does not reach a website on its
   own. The path is:

       InOne > Agent One > AI Agents        the agent itself
       MindBehind Flow > Assistants         a flow with the
                                            "Use Shopping AI Agent (LLM)" module
       MindBehind Flow > Channels           a Web Messenger channel
       -> a channel id, which is what this file needs

   The channel id is the only thing that travels from MindBehind to here.
   Everything else — personality, knowledge base, actions, which InOne agent
   the flow points at — lives in the two panels.

   HOW IT IS WIRED

   Twelve storefronts share one codebase and one account, so there is one
   channel id per vertical, resolved the same way `searchCampaignId` is: by
   the vertical key vertical.js writes to window.VERTICAL_KEY.

   The map starts empty. A vertical with no channel id loads nothing at all —
   no script tag, no network call, no DOM node. So this can go live with one
   vertical filled in and the other eleven untouched.

   OFF BY DEFAULT IS DELIBERATE. Until CHANNELS below has an entry, adding
   the script tag to the pages changes nothing anywhere.

   TESTING WITHOUT A DEPLOY

       ?agent=<channelId>   run any channel on any storefront, right now
       ?agent=off           kill it for this page load
       ?agent-api=test      load the SDK against MindBehind's test API

   The URL override is the useful one while the agent is still being built:
   a channel can be pointed at fashion, then at hotels, then at telco,
   without a push in between.

   MindBehind also has a standalone harness that skips the site entirely:

       https://app.mindbehind.com/chatbot-test?channelId=<channelId>

   ISOLATION

   Same rule as affinity.js. Own namespace, one injected script tag, no
   runtime wrappers around anything else, nothing imported by another file.
   Remove the script tag from the pages and the estate is exactly as it was.
   -------------------------------------------------------------------------- */
(function () {
  'use strict';

  /* --- channel ids ---------------------------------------------------------
     One MindBehind Web Messenger channel per vertical.

     These sit here rather than in config.js on purpose, for now. config.js
     holds campaign ids that several files read; a channel id is read by this
     file and nothing else. When the agent stops being an experiment it should
     move to config.js under `agent.perAccount.partnersandbox`, alongside the
     Eureka and reco ids, and the applier's ['eureka','reco'] list gains
     'agent'. Not before — a config section that only one optional file reads
     is a config section that goes stale.

     DEFAULT is the fallback for any vertical without its own entry. While
     there is a single channel, put it there and every storefront gets the
     same agent; that is wrong for a real demo but right for finding out
     whether the thing renders. Once there are twelve, DEFAULT goes to null so
     a missing id fails visibly rather than silently serving the wrong brand.
     -------------------------------------------------------------------------- */
  var DEFAULT = null;

  /* Three channels, three agents. The nine subvertical storefronts share ONE
     agent: the MindBehind widget hands it the product being viewed (via the
     Insider SDK on the page), the product's brand attribute tells it which
     store it is standing in, and its knowledge bases and single action carry
     every brand. Ten per-brand agents were built first and thrown away when
     that turned out to be true — see the page-context note below.

     MISUMI and Canon are separate on purpose: POCs with their own knowledge
     base, and Canon in its own locale (en_CA), so a customer's agent only
     ever sees the customer's catalogue. */
  var SHARED = { sandbox: '6aa547a91e38ba0119dfcaf5', demo: null };   // "Shared Web" channel

  var CHANNELS = {
    fashion:     SHARED,   // Ashford Lane
    beauty:      SHARED,   // Lumen
    home:        SHARED,   // Aldgate
    supermarket: SHARED,   // Harvest Row
    hotels:      SHARED,   // Wayfarer
    airlines:    SHARED,   // Meridian Air
    banking:     SHARED,   // Northbank
    telco:       SHARED,   // Vantis
    electronics: SHARED,   // Kestrel
    luxury:      SHARED,   // Beaumont Vale
    insurance:   SHARED,   // Fairhaven
    fintech:     SHARED,   // Loop
    nutrition:   SHARED,   // Verdant
    misumi:      { sandbox: '6aa41e6b1e38ba0119dfc942', demo: null },   // MISUMI — own agent
    canon:       { sandbox: '6aa51e051e38ba0119dfca63', demo: null }    // Canon Canada — own agent, en_CA
  };

  /* Layout flags, applied to `window` before the SDK loads because that is
     when it reads them. All optional; the defaults are the SDK's own.

       fullScreen        open the messenger full screen rather than as a panel
       hideHeader        drop the messenger's own header bar
       openOnLoad        open the panel without waiting for a click
       hideIcon          hide the floating button entirely
       disableIconClick  leave the button visible but inert

     hideIcon is for triggering the widget from your own UI. Nothing here does
     that yet, so leaving it false keeps the launcher as the way in. */
  var OPTIONS = {
    fullScreen: false,
    hideHeader: false,
    openOnLoad: false,
    hideIcon: false,
    disableIconClick: false
  };

  var SDK = 'https://cdn.mindbehind.com/sdk/mindbehind-sdk.js';
  var MOUNT_ID = 'MB_WEBCHAT_WIDGET';   // the node the SDK creates
  var TAG_ID = 'ins-agent-sdk';         // the script tag this file creates

  /* --- helpers ------------------------------------------------------------ */
  function note(msg, level) {
    // Every line is prefixed, so a MindBehind problem is never mistaken for an
    // Insider One one. They are two platforms and two support paths.
    if (window.insDebugNote) window.insDebugNote('agent (mindbehind): ' + msg, level || 'info');
  }

  function param(name) {
    var m = new RegExp('[?&]' + name + '=([^&#]*)').exec(window.location.search);
    return m ? decodeURIComponent(m[1]) : null;
  }

  /* Resolution order: URL override, then this vertical, then DEFAULT.
     Returns null when there is nothing to load, which is the normal state
     for a vertical whose agent has not been built yet. */
  function channelId() {
    var override = param('agent');
    if (override) {
      if (override === 'off' || override === '0' || override === 'false') return null;
      note('channel ' + override + ' from ?agent= override', 'warn');
      return override;
    }
    if (param('agent') === '' ) return null;

    var key = window.VERTICAL_KEY;
    if (!key) return null;
    /* An entry is either one id (same agent on both accounts) or a pair:
       { sandbox: '<partnersandbox channel>', demo: '<salesdemo channel>' }.
       The agent's action writes to one Insider account, so once salesdemo
       has its own agents every vertical becomes a pair, picked by the
       environment the hostname resolved to. A missing half stays null and
       fails visibly, as before. */
    var entry = CHANNELS[key];
    if (entry && typeof entry === 'object') {
      var env = window.ENVIRONMENT_KEY === 'sandbox' ? 'sandbox' : 'demo';
      return entry[env] || null;
    }
    return entry || DEFAULT || null;
  }

  /* --- load --------------------------------------------------------------- */
  function load() {
    if (document.getElementById(TAG_ID)) return true;   // already injected
    if (document.getElementById(MOUNT_ID)) return true;  // already mounted

    var id = channelId();
    if (!id) return true;   // nothing configured for this vertical — done, silently

    if (param('agent') === 'off') { note('disabled for this page load', 'warn'); return true; }

    // Layout flags must be on window BEFORE the script runs.
    if (OPTIONS.fullScreen)       window.mbIsFullScreen = true;
    if (OPTIONS.hideHeader)       window.mbHideHeader = true;
    if (OPTIONS.openOnLoad)       window.mbWidget = true;
    if (OPTIONS.hideIcon)         window.mbHideIcon = true;
    if (OPTIONS.disableIconClick) window.mbOnclickDisabled = true;

    var src = SDK + '?auto=true&key=' + encodeURIComponent(id);
    if (param('agent-api') === 'test') {
      src += '&api=test';
      note('loading against the TEST api', 'warn');
    }

    var s = document.createElement('script');
    s.id = TAG_ID;
    s.async = true;
    s.src = src;

    s.onload = function () {
      note('sdk loaded, channel ' + id + ' on ' + (window.VERTICAL_KEY || '?'), 'ok');
      /* The SDK mounts asynchronously after its own bootstrap, so a missing
         node here means the channel id was rejected or the channel has no
         published deployment — both of which fail quietly on MindBehind's
         side and would otherwise look like "nothing happened". */
      setTimeout(function () {
        if (!document.getElementById(MOUNT_ID)) {
          note('sdk loaded but no widget mounted. Usually the channel has no ' +
               'published deployment, or the assistant version is not linked ' +
               'to this channel. Check it in isolation at ' +
               'https://app.mindbehind.com/chatbot-test?channelId=' + id, 'warn');
        }
      }, 4000);
    };

    s.onerror = function () {
      note('sdk failed to load from ' + SDK + ' — network, or the CDN is blocked', 'error');
    };

    document.head.appendChild(s);
    note('injecting channel ' + id, 'info');
    return true;
  }

  /* vertical.js writes VERTICAL_KEY at parse time and this file is loaded
     after it, so the first call normally succeeds. The poll is the same
     belt-and-braces config.js uses: if ordering ever changes, keep looking
     briefly rather than silently loading nothing. */
  if (!window.VERTICAL_KEY) {
    var tries = 0;
    var t = setInterval(function () {
      if (window.VERTICAL_KEY || ++tries > 100) { clearInterval(t); load(); }
    }, 20);
  } else {
    load();
  }

  /* --- page context ---------------------------------------------------------
     Nothing to do here, and that was a surprise: the MindBehind widget reads
     the Insider SDK on the page directly (mb-webchat, useInsider.js) and
     forwards INSIDER_ID, LOCALE, CURRENCY, IS_LOGGED_IN, PARTNER_NAME and, on
     a real product page, CURRENT_PRODUCT — the product id travels with every
     message as productId, and the Shopping Agent takes it as item_id. So "this
     product" and the storefront's locale (Canon is en_CA) reach the agent
     without any parameter from this file.

     The one condition: window.Insider must exist, which means the hostname
     has to be in the account's multiDomains. On a hostname the tag will not
     load for, the agent gets no locale and no product. That is the first
     thing to check when a storefront's chat seems to know nothing.

     What is NOT passed to the agent is the brand. CHAT_URL and any window.MB_*
     parameter reach the MindBehind flow (usable for routing on the canvas),
     not the Agent One agent. On a product page the agent can read the brand
     off the product's own brand attribute, which is enough for a demo that
     starts on a product page.
     ---------------------------------------------------------------------- */
})();
